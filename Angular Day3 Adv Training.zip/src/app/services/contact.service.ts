import { Injectable } from '@angular/core';
import { Contact } from '../models/contact';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  contacts: Contact[];
  constructor() {
    this.contacts = [
      {
        contactId: 101, firstName: 'Senthil Kumar', lastName: 'Tamilarasan',
        mobileNumber: '9894439422', alternateMobileNumber: null, mailId:
          'stamilarasan@humana.com', orgnization: 'Cognizant', dob: new Date('25/05/1985')
      },
      {
        contactId: 102, firstName: 'Senthil Kumar', lastName: 'Tamilarasan',
        mobileNumber: '9894439422', alternateMobileNumber: null, mailId:
          'stamilarasan@humana.com', orgnization: 'Cognizant', dob: new Date('25/05/1985')
      }
    ];
  }

  getAll(): Contact[] {
    return this.contacts;
  }

  get(id: number) {
    return this.contacts.find((c) => c.contactId === id);
  }

  add(contact: Contact) {
    this.contacts.push(contact);
  }

  update(contact: Contact) {
    let index = this.contacts.findIndex((c) => c.contactId === contact.contactId);
    if (index > -1) {
      this.contacts[index] = contact;
    }
  }

  delete(id: number) {
    let index = this.contacts.findIndex((c) => c.contactId === id);
    if (index > -1) {
      this.contacts.splice(index, 1);
    }
  }
}
